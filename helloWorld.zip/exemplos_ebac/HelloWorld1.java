public class HelloWorld1 {
 
  public static void main(String[] args) {
    System.out.print("Ola" + " " +args[0] + " " +args[1]);
  };
    

}